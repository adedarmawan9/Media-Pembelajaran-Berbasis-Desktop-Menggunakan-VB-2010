﻿Public Class Form7

    Private Sub result2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Label3.Text = Form1.TextBox1.Text
        Label4.Text = Form1.TextBox2.Text
        If TextBox1.Text >= 7 Then
            MessageBox.Show("Anda Orang TI Sejati")
        ElseIf TextBox1.Text < 6 Then
            MessageBox.Show("Belajarlah Lebih giat lagi")
        End If
    End Sub
End Class